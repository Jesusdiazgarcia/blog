<?php 
include get_template_directory() . '/assets/inc/css-functions.php'; 
include get_template_directory() . '/assets/inc/js-functions.php'; 


