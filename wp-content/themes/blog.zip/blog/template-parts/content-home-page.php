<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package blog
 */

?>
<main class="container-fluid fondo">
  
      <!-- carrusel swiper -->
       <section class="container col-12">
            <div class="swiper pt-5">
              <!-- Additional required wrapper -->
            <div id="mostrarcarrusel" class="swiper-wrapper">
                <!-- Slides -->
                
            </div>
              <!-- If we need pagination -->
              <div class="swiper-pagination"></div>
            
             
              
            
            
            </div>
      <!-- carrusel swiper -->
      <!-- <img class=" col-md-4 col-12 borde1 offset-md-4" src=" " alt="xs"> -->
              <!--  api moment -->

           <div id="showentrada" class="container mt-5" > 
               
           
               <img class=" col-md-4 col-12 borde1 offset-md-4" src="https://jediazg.laboratoriodiseno.cl/wp-content/uploads/2023/11/ultima-cena.webp" alt="xs">
               <div  class="resultado col-md-4 col-12 offset-md-4">
                <h3  class="text-center semana1">Titulo</h3>
                <h4 class="ms-1 quei">¿Que hice?</h4>
                <p class="ms-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi accusantium magni </p>
                <h4 class="ms-1 quei">¿Que aprendi?</h4>
                <p class="ms-2 pb-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi accusantium magni</p>

               
               <!--  api moment -->
        </div>
       </section>
       
       
    </main>
    
   