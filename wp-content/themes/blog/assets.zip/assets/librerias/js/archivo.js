jQuery(document).ready(function ($) {
    var swiper = new Swiper('.swiper', {
        // Optional parameters
        direction: 'horizontal',
        loop: false,
        spaceBetween: 30,
        clickable: true,
        slidesPerView: 3,
        // If we need pagination
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
            dynamicBullets: true,
        },

        // Navigation arrows
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },


    });
    function moverentrada (carruselent) {
        $.get("/blog/wp-json/wp/v2/posts/" + carruselent, function (sliderValue) {

            var sliderentrada = '<div class="resultado col-md-4 col-12 offset-md-4"><h3  class="text-center semana1">' + sliderValue.title["rendered"] + '</h3><p class="ms-2 pb-2">' + sliderValue.content["rendered"] + '</p></div>';
            $("#showentrada").empty().append(sliderentrada);


    
     });



    }
});